import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeesService {
  
  employees: any;

  constructor() { }
  all(): Observable<Array<object>> {
    return of(this.employees);
  }
  
  findOne(id: string): Observable<object> {
    const user = this.employees.find((u: any) => {
      return u.id === id;
    });
    return of(user);
  }
}
