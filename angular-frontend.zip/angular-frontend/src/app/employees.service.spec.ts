import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { EmployeesService } from './employees.service';

describe('EmployeesService', () => {
  let service: EmployeesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  describe('findOne', () => {
    it('should return a single user', () => {
      const employeeResponse = {
        id: '2',
        firstname: 'Bob',
        lastname: 'abc',
        emailId: 'bob@gmail.com'
      };
      let response;
      spyOn(EmployeesService, 'findOne').and.returnValue(of(employeeResponse));
  
      EmployeesService.findOne('2').subscribe(res => {
        response = res;
      });
  
      expect(response).toEqual(employeeResponse);
    });
  });
});
