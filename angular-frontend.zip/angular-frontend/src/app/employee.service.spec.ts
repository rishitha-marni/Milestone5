import { TestBed } from '@angular/core/testing';
import { of } from 'rxjs';

import { EmployeeService } from './employee.service';

describe('EmployeeService', () => {
  let service: EmployeeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  describe('all', () => {
    it('should return a collection of users', () => {
      const employeeResponse = [
        {
          id: '1',
          firstname: 'ria',
          lastname: 'marni',
          emailId: 'ria@gmail.com'
        },
        {
          id: '2',
          firstname: 'rishi',
          lastname: 'marni',
          emailId: 'rishi@gmail.com'
        }
      ];
      let response;
      spyOn(EmployeeService, 'all').and.returnValue(of(employeeResponse));

      EmployeeService.all().subscribe(res => {
        response = res;
      });

      expect(response).toEqual(employeeResponse);
    });
  });
});

